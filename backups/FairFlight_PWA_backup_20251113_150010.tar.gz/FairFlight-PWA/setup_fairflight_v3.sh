#!/bin/bash
echo "🚀 Setting up FairFlight v3 (Smart Data Memory)..."

# === index.html ===
cat > index.html <<'HTML'
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>FairFlight</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <h1>FairFlight</h1>
  <p>Your flight made fair and easy.</p>

  <label>From:</label>
  <select id="from">
    <option value="">Select origin</option>
    <option value="Nairobi">Nairobi</option>
    <option value="Mombasa">Mombasa</option>
    <option value="Kisumu">Kisumu</option>
  </select>

  <label>To:</label>
  <select id="to">
    <option value="">Select destination</option>
    <option value="Mombasa">Mombasa</option>
    <option value="Nairobi">Nairobi</option>
    <option value="Kisumu">Kisumu</option>
  </select>

  <label>Date:</label>
  <input type="date" id="date" />

  <label>Sort by:</label>
  <select id="sort">
    <option value="none">None</option>
    <option value="price">Price</option>
    <option value="departure">Departure</option>
  </select>

  <button id="checkFlightsBtn">Check Available Flights</button>
  <div id="flightResults"></div>

  <script src="app.js"></script>
</body>
</html>
HTML

# === app.js ===
cat > app.js <<'JS'
document.addEventListener("DOMContentLoaded", () => {
  const from = document.getElementById("from");
  const to = document.getElementById("to");
  const date = document.getElementById("date");
  const sort = document.getElementById("sort");
  const resultsDiv = document.getElementById("flightResults");
  const checkBtn = document.getElementById("checkFlightsBtn");

  // 🧠 Load saved selections
  const savedData = JSON.parse(localStorage.getItem("fairflight-data"));
  if (savedData) {
    from.value = savedData.from || "";
    to.value = savedData.to || "";
    date.value = savedData.date || "";
    sort.value = savedData.sort || "none";
  }

  checkBtn.addEventListener("click", async () => {
    const searchData = {
      from: from.value,
      to: to.value,
      date: date.value,
      sort: sort.value
    };

    // 💾 Save selections to localStorage
    localStorage.setItem("fairflight-data", JSON.stringify(searchData));

    resultsDiv.innerHTML = "<p>⏳ Loading flights...</p>";

    const res = await fetch("flights.json");
    const flights = await res.json();

    setTimeout(() => {
      let filtered = flights.filter(f => 
        f.from === searchData.from && f.to === searchData.to
      );

      if (searchData.sort === "price") {
        filtered.sort((a, b) => a.price - b.price);
      } else if (searchData.sort === "departure") {
        filtered.sort((a, b) => a.time.localeCompare(b.time));
      }

      resultsDiv.innerHTML = "";
      if (filtered.length === 0) {
        resultsDiv.innerHTML = "<p>❌ No flights found.</p>";
        return;
      }

      filtered.forEach(f => {
        const flightInfo = document.createElement("p");
        flightInfo.textContent = `✈ ${f.from} → ${f.to} | Date: ${searchData.date} | Time: ${f.time} | Price: $${f.price}`;
        resultsDiv.appendChild(flightInfo);
      });
    }, 1000);
  });
});
JS

echo "✅ FairFlight v3 setup complete! Smart memory now active."
